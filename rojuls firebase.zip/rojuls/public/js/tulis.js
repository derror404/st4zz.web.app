new TypeIt('#desc', {
  speed: 60
})
.type('Mudah disebut, gampang diingat, dan sulit untuk dilupakan... :D');